$('.FAQ1').click(function() {
	$('.infaq').slideToggle(260);
})
$('.FAQ1').click(function() {
	$('.FAQ1 .icon').toggle()
})
$('.FAQ1').click(function() {
	$('.FAQ1 .up').toggle()
})
$('.FAQ1 .up').hide()
$('.infaq a').click(function() {
	$('.infaq').remove()
})
$('.infaq a').click(function() {
	$('.FAQ1').remove()
})
$('.infaq .cancel').click(function() {
	$('.infaq').slideUp(260)
})
$('.infaq .cancel').click(function() {
	$('.icon').show()
})
$('.infaq .cancel').click(function() {
	$('.up').hide()
})
$('.infaq .cancel').click(function() {
	$('.infaq .infaqin').html('<input type="text" name="" placeholder="Add a Question:i.e. Do you translate to English as well?" value="Is this email signature responsive?">')
})
$('.infaq .cancel').click(function() {
	$('.infaq .textareain').html('<textarea placeholder="Add an Answer: i.e Yes, I also translate from English to Hebrew" class="textarea">Yes, this email signature is responsive. For that reason, the user can view the email signature on any device.</textarea>')
})
$('.text a').click(function() {
	$('.addfaq').show()
})
$('.text a').click(function() {
	$('.text a').hide()
})
$('.addfaq .cancel').click(function() {
	$('.addfaq').hide()
})
$('.addfaq .cancel').click(function() {
	$('.text a').show()
})
$('.addfaq .add').click(function() {
	$('.FAQadd').show()
})
$('.addfaq .add').click(function() {
	$('.FAQS').prepend('<div class="FAQadd FAQ"></div>')
})
$('.addfaq .add').click(function() {
	$('.FAQadd .h3').html('<h3>Will you help to install the email signature in clients device?</h3>')
})

$('.addfaq .add').click(function() {
	$('.FAQadd .iconn').html('<i class="fas fa-angle-down"></i>')
})
$('.addfaq .add').click(function() {
	$('.addfaq').hide()
})
$('.addfaq .cancel').click(function() {
	$('.addfaq .input').html('<input type="text" value="" name="" placeholder="Add a Question: i.e. Do you translate to English as well?">')
})
$('.addfaq .add').click(function() {
	$('.addfaq .input').html('<input type="text" value="" name="" placeholder="Add a Question: i.e. Do you translate to English as well?">')
})
$('.addfaq .add').click(function() {
	$('.addfaq .textarea').html('<textarea placeholder="Add an Answer: i.e Yes, I also translate from English to Hebrew"></textarea>')
})
$('.addfaq .add').click(function() {
	$('.text a').show()
})
$('.addfaq .cancel').click(function() {
	$('.addfaq .textarea').html('<textarea placeholder="Add an Answer: i.e Yes, I also translate from English to Hebrew"></textarea>')
})






$('.FAQ2').click(function() {
	$('.infaq2').slideToggle(260)
})
$('.FAQ2').click(function() {
	$('.FAQ2 .icon').toggle()
})
$('.FAQ2').click(function() {
	$('.FAQ2 .up').toggle()
})
$('.FAQ2 .up').hide()
$('.infaq2 a').click(function() {
	$('.infaq2').remove()
})
$('.infaq2 a').click(function() {
	$('.FAQ2').remove()
})
$('.infaq2 .cancel').click(function() {
	$('.infaq2').slideUp(260)
})
$('.infaq2 .cancel').click(function() {
	$('.icon').show()
})
$('.infaq2 .cancel').click(function() {
	$('.up').hide()
})
$('.infaq2 .cancel').click(function() {
	$('.infaq2 .infaqin').html('<input type="text" name="" placeholder="Add a Question:i.e. Do you translate to English as well?" value="Is this email signature responsive?">')
})
$('.infaq2 .cancel').click(function() {
	$('.infaq2 .textareain').html('<textarea placeholder="Add an Answer: i.e Yes, I also translate from English to Hebrew" class="textarea">Yes, this email signature is responsive. For that reason, the user can view the email signature on any device.</textarea>')
})



$('.FAQadd').click(function() {
	$('.infaq3').slideToggle(260)
})
$('.FAQadd').click(function() {
	$('.FAQadd .icon').toggle()
})
$('.FAQ3').click(function() {
	$('.FAQadd .up').toggle()
})
$('.FAQadd .up').hide()
$('.infaq3 a').click(function() {
	$('.infaq3').remove()
})
$('.infaq3 a').click(function() {
	$('.FAQadd').remove()
})
$('.infaq3 .cancel').click(function() {
	$('.infaq3').slideUp(260)
})
$('.infaq3 .cancel').click(function() {
	$('.icon').show()
})
$('.infaq3 .cancel').click(function() {
	$('.up').hide()
})
$('.infaq3 .cancel').click(function() {
	$('.infaq3 .infaqin').html('<input type="text" name="" placeholder="Add a Question:i.e. Do you translate to English as well?" value="Will you help to install the email signature in clients device?">')
})
$('.infaq3 .cancel').click(function() {
	$('.infaq3 .textareain').html('<textarea placeholder="Add an Answer: i.e Yes, I also translate from English to Hebrew" class="textarea">Yes, I will help you to install the email signature in your device.</textarea>')
})
